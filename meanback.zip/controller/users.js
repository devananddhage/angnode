'use strict';
var User = require('../model/users.js');
const jwt = require('jsonwebtoken');

require('dotenv').config();

exports.list_all_users = function (req, res) {
    const payload = req.decoded;
    
    User.getAllUsers(function (err, user) {
        if (err)
            res.send(err);
        res.send(user);
    });
};
exports.create_a_user = function (req, res) {
    var new_user = new User(req.body);
    if (!new_user.student_name || !new_user.status) {
        res.status(400).send({
            error: true,
            message: 'Please provide user'
        });
    } else {
        User.createUser(new_user, function (err, student_name) {
            if (err)
                res.send(err);
            res.json(student_name);
        });
    }
};

exports.read_a_user = function (req, res) {
    User.getUserByName(req.params.userName, function (err, user) {
        if (err)
            res.send(err);
        res.json(user);
    });
};


exports.login = function (req, res) {
    const {
        userName
    } = req.body;

    let result = {};
    let status = 200;

    User.getUserByName(userName, function (err, user) {
        
        if (err) {
            status = 401;
            result.status = status;
            result.error = `Authentication error`;
            res.status(status).send(result);
        }

        if (userName === user[0].student_name) {
            status = 200;
            // Create a token
            const payload = {
                user: user[0].student_name
            };
            const options = {
                expiresIn: '60000',
                issuer: 'https://scotch.io'
            };

            const secret = process.env.JWT_SECRET;
            const token = jwt.sign(payload, secret, options);

            result.token = token;
            result.status = status;
            result.result = user;
            res.status(status).send(result);
        } else {
            status = 404;
            result.status = status;
            result.error = err;
            res.status(status).send(result);
        }
    });
};