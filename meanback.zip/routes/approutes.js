'use strict';
module.exports = function (app) {
  const todoList = require('../controller/appController'),
    users = require('../controller/users'),
    validateToken = require('../controller/utils').validateToken;

  // todoList Routes
  app.route('/tasks')
    .get(validateToken, todoList.list_all_tasks)
    .post(validateToken, todoList.create_a_task);

  app.route('/task/:taskId')
    .get(validateToken, todoList.read_a_task)
    .put(validateToken, todoList.update_a_task)
    .delete(validateToken, todoList.delete_a_task);

  app.route('/users')
    .get(validateToken, users.list_all_users);

  app.route('/users/:userName')
    .get(validateToken, users.read_a_user);

  app.route('/login')
    .post(users.login)
};