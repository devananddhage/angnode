var sql = require('./db.js');

//User object constructor
var User = function (user) {
    this.student_name = user.student_name;
    this.student_email = user.student_email;
    this.section = user.section;
    this.status = user.status;
    this.gender = user.gender;
    this.dob = new Date();
};

User.createUser = function (newUser, result) {
    // INSERT INTO `student` (`student_id`, `student_name`, `student_email`, `section`, `gender`, `dob`, `is_active`) VALUES ('1', 'devanand', 'dvdhage@gmail.com', 'IT', 'Male', '2020-02-12 00:00:00', '1');
    sql.query("INSERT INTO student set ?", newUser, function (err, res) {
        if (err) {
            result(err, null);
        } else {
            result(null, res.insertId);
        }
    });
};
User.getAllUsers = function (result) {
    sql.query("Select * from student", function (err, res) {
        if (err) {
            result(null, err);
        } else {
            result(null, res);
        }
    });
};
User.getUserByName = function (studentname, result) {
    sql.query("Select student_name from student where student_name = ? ", studentname, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        } else {
            result(null, res);
        }
    });
};

module.exports = User;