export class Student {
    id;
    task;
    status;
    createdAt: Date;
}
