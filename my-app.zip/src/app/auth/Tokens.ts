class Tokens {
    token;
    refreshToken;
}
