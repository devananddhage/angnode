import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { tap, mapTo, catchError } from 'rxjs/operators';
import { of, Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  loggedInUSer: any;
  endpoint = environment.apiBaseUrl;
  // headers = new HttpHeaders().set('Content-Type', 'application/json');

  private readonly JWT_TOKEN = 'JWT_TOKEN';
  private readonly REFRESH_TOKEN = 'REFRESH_TOKEN';

  constructor(private http: HttpClient) { }
  // private jwtHelper: JwtHelperService,

  Login(data: { userName: string, password: string }): Observable<boolean> {
    const url = `${this.endpoint}/login`;
    console.log(url);
    return this.http.post(url, data)
      .pipe(
        tap((tokens: Tokens) => this.doLoginUser(data.userName, tokens)),
        mapTo(true),
        catchError(error => {
          return of(false);
        })
      );
  }

  Logout() {
    const url = `${this.endpoint}/logout`;
    return this.http.post(url, {
      refreshToken: this.getRefreshToken()
    }).pipe(
      tap(() => this.doLogoutUser()),
      mapTo(true),
      catchError(error => {
        return of(false);
      })
    );
  }

  RefreshToken() {
    const url = `${this.endpoint}/refresh`;
    return this.http.post(url, {
      refreshToken: this.getRefreshToken()
    }).pipe(
      tap((tokens: Tokens) => {
        return this.storeJwtToken(tokens.token);
      }),
      mapTo(true),
      catchError(error => {
        return of(false);
      })
    );
  }
  getToken() {
    return this.getJwtToken();
  }

  private doLogoutUser(): void {
    this.loggedInUSer = null;
    localStorage.removeItem(this.JWT_TOKEN);
    localStorage.removeItem(this.REFRESH_TOKEN);
  }
  private getJwtToken() {
    return localStorage.getItem(this.JWT_TOKEN);
  }
  private storeJwtToken(token) {
    localStorage.setItem(this.JWT_TOKEN, token);
  }
  private getRefreshToken() {
    return localStorage.getItem(this.REFRESH_TOKEN);
  }

  private doLoginUser(userName, tokens) {
    this.loggedInUSer = userName;
    localStorage.setItem(this.JWT_TOKEN, tokens.token);
    localStorage.setItem(this.REFRESH_TOKEN, tokens.refreshToken);
  }

  public isAuthenticated(): boolean {
    const token = localStorage.getItem(this.JWT_TOKEN);
    return (token !== null && token !== undefined);
    // return !this.jwtHelper.isTokenExpired(token);
  }
}
