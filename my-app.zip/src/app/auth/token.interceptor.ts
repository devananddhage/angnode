import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { AuthService } from './auth.service';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable()
export class AuthHeaderInterceptor implements HttpInterceptor {

    constructor(public auth: AuthService, private router: Router) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        const token = this.auth.getToken();

        if (token !== undefined && token !== null) {
            let contentType = '';
            if (request.headers.has('Content-Type')) {
                contentType = request.headers.get('Content-Type');
            }
            const customReq = request.clone({
                setHeaders: {
                    Authorization: `Bearer ${token}`
                }
            });
            return next.handle(customReq).pipe(catchError(error => {
                if (error instanceof HttpErrorResponse && error.status === 401) {
                    console.log('401 - intercept');
                    // return this.handle401Err(customReq, next);
                    this.router.navigate(['login']);
                    return throwError(error);
                } else {
                    console.log('401 else - intercept');
                    return throwError(error);
                }
            }));
        } else {
            return next.handle(request);
        }
    }

    handle401Err(customReq: HttpRequest<any>, next: HttpHandler): any {
        throw new Error('Method not implemented.');
    }
}
